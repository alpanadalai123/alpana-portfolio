/* =====================================================
                    HAMBURGER
===================================================== */

const hamburger =
    document.getElementById("hamburger");

const navMenu =
    document.getElementById("navMenu");


hamburger.addEventListener("click", () => {

    hamburger.classList.toggle("open");

    navMenu.classList.toggle("open");

});


/* Close mobile menu */

document.querySelectorAll(".nav-menu a")
    .forEach(link => {

        link.addEventListener("click", () => {

            hamburger.classList.remove("open");

            navMenu.classList.remove("open");

        });

    });



/* =====================================================
                    NAVBAR SCROLL
===================================================== */

const navbar =
    document.querySelector(".navbar");


window.addEventListener("scroll", () => {

    if (window.scrollY > 30) {

        navbar.classList.add("scrolled");

    } else {

        navbar.classList.remove("scrolled");

    }

});



/* =====================================================
                    MOUSE EFFECT
===================================================== */

const hero =
    document.querySelector(".hero");

const photo =
    document.querySelector(".hero-photo");

const shapes =
    document.querySelectorAll(".shape");


if (window.innerWidth > 760) {

    hero.addEventListener("mousemove", (e) => {

        const rect =
            hero.getBoundingClientRect();

        const x =
            (e.clientX - rect.left)
            / rect.width - 0.5;

        const y =
            (e.clientY - rect.top)
            / rect.height - 0.5;


        /* Image movement */

        photo.style.transform =
            `translate(
                ${x * 12}px,
                ${y * 10}px
            )`;


        /* Background shapes */

        shapes.forEach((shape, index) => {

            const amount =
                (index + 1) * 5;

            shape.style.marginLeft =
                `${x * amount}px`;

            shape.style.marginTop =
                `${y * amount}px`;

        });

    });


    hero.addEventListener("mouseleave", () => {

        photo.style.transform =
            "translate(0,0)";

        shapes.forEach(shape => {

            shape.style.marginLeft = "0";
            shape.style.marginTop = "0";

        });

    });

}

/* =========================
   ABOUT REVEAL
========================= */

const aboutElements = document.querySelectorAll(".reveal-about");

const aboutObserver = new IntersectionObserver(
    (entries, observer) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("show");

                observer.unobserve(entry.target);

            }

        });

    },
    {
        threshold: 0.2
    }
);

aboutElements.forEach(element => {
    aboutObserver.observe(element);
});


/* =========================
   COUNTER
========================= */

const counters = document.querySelectorAll(".counter");

let counterStarted = false;

const counterObserver = new IntersectionObserver(
    entries => {

        entries.forEach(entry => {

            if (entry.isIntersecting && !counterStarted) {

                counterStarted = true;

                counters.forEach(counter => {

                    const target = Number(counter.dataset.target);

                    let current = 0;

                    const duration = 1200;
                    const step = target / (duration / 20);

                    const updateCounter = () => {

                        current += step;

                        if (current < target) {

                            counter.textContent = Math.floor(current);

                            requestAnimationFrame(updateCounter);

                        } else {

                            counter.textContent = target;

                        }

                    };

                    updateCounter();

                });

            }

        });

    },
    {
        threshold: 0.5
    }
);

const stats = document.querySelector(".about-stats");

if (stats) {
    counterObserver.observe(stats);
}

/* =========================
   SKILLS REVEAL
========================= */

const skillElements = document.querySelectorAll(".reveal-skill");

const skillObserver = new IntersectionObserver(
    (entries, observer) => {

        entries.forEach(entry => {

            if (entry.isIntersecting) {

                entry.target.classList.add("show");

                /* Progress bars */

                const bars = entry.target.querySelectorAll(
                    ".skill-bar span"
                );

                bars.forEach(bar => {

                    const width = bar.dataset.width;

                    setTimeout(() => {

                        bar.style.width = width;

                    }, 300);

                });

                observer.unobserve(entry.target);
            }

        });

    },
    {
        threshold: 0.18
    }
);


skillElements.forEach(element => {

    skillObserver.observe(element);

});


/* =========================================================
   PROJECT DATA
========================================================= */

const projectData = [

    /* =====================================================
       1. BURGER E-COMMERCE
    ===================================================== */

    {
        image: "images/burger.png",

        category: "WEB DEVELOPMENT",

        title: "Burger E-Commerce",

        description:
            "A modern food e-commerce website where users can explore products, view product details, manage their cart and interact with a complete shopping interface.",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript",
            "PHP",
            "MySQL"
        ],

        features: [
            "Product listing and categories",
            "Product details page",
            "Add to cart system",
            "Customer login and session",
            "Responsive design"
        ],

        live:
            "https://your-burger-demo-link.com",

        github:
            "https://github.com/yourusername/burger"
    },


    /* =====================================================
       2. COMPUTER REPAIR
    ===================================================== */

    {
        image: "images/computer.png",

        category: "WEB DESIGN",

        title: "Computer Repair",

        description:
            "A modern computer repair and support website designed for a computer shop. It presents repair services, products, repair process, customer reviews and an online repair booking system.",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript"
        ],

        features: [
            "Screen replacement service",
            "Battery and charging repair",
            "Data recovery and backup",
            "Virus and security removal",
            "Book a repair form",
            "Customer reviews",
            "Responsive design"
        ],

        live:
            "https://your-computer-repair-demo.com",

        github:
            "https://github.com/yourusername/computer-repair"
    },


    /* =====================================================
       3. POKEMON
    ===================================================== */

    {
        image: "images/pokemon.png",

        category: "REACT PROJECT",

        title: "Pokémon Explorer",

        description:
            "A React based Pokémon explorer that fetches data from the Pokémon REST API and displays Pokémon information through interactive cards and detailed pages.",

        technologies: [
            "React",
            "Axios",
            "REST API",
            "JavaScript"
        ],

        features: [
            "Pokémon API integration",
            "Dynamic Pokémon cards",
            "Pagination",
            "Previous and Next navigation",
            "Detailed Pokémon information",
            "Dynamic routes"
        ],

        live:
            "https://your-pokemon-demo.com",

        github:
            "https://github.com/yourusername/pokemon"
    },


    /* =====================================================
       4. EDUCATION DASHBOARD
    ===================================================== */

    {
        image: "images/dashboard.png",

        category: "REACT UI",

        title: "Education Dashboard",

        description:
            "A modern education dashboard interface built with React and Tailwind CSS. The dashboard provides a clean responsive layout for educational statistics and information.",

        technologies: [
            "React",
            "Tailwind CSS",
            "JavaScript"
        ],

        features: [
            "Responsive sidebar",
            "Dashboard statistics",
            "Modern card layout",
            "Reusable React components",
            "Responsive design"
        ],

        live:
            "https://your-dashboard-demo.com",

        github:
            "https://github.com/yourusername/education-dashboard"
    },


    /* =====================================================
       5. SCHOOL WEBSITE
    ===================================================== */

    {
        image: "images/sc.png",

        category: "WEB DESIGN",

        title: "School Website",

        description:
            "A responsive school website created to present academic information, events, facilities, gallery and contact information in a professional interface.",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript",
            "Bootstrap"
        ],

        features: [
            "Academic information",
            "Events section",
            "Gallery",
            "Facilities section",
            "Contact section"
        ],

        live:
            "https://sarpai.santupramanik.online/",

        github:
            "https://github.com/yourusername/school-website"
    },


    /* =====================================================
       6. PERSONAL PORTFOLIO
    ===================================================== */

    {
        image: "project6.jpg",

        category: "PORTFOLIO",

        title: "Personal Portfolio",

        description:
            "A modern personal portfolio website focused on clean visual design, smooth animations, responsive layouts and interactive sections to showcase development skills and projects.",

        technologies: [
            "HTML",
            "CSS",
            "JavaScript"
        ],

        features: [
            "Animated hero section",
            "Responsive navigation",
            "Interactive project section",
            "Animated statistics",
            "Responsive design"
        ],

        live:
            "https://alpanadalai.online",

        github:
            "https://github.com/yourusername/portfolio"
    }

];



/* =========================================================
   SELECT ELEMENTS
========================================================= */

const projectCards =
    document.querySelectorAll(".project-card");

const projectModal =
    document.getElementById("projectModal");

const modalClose =
    document.getElementById("modalClose");

const modalImage =
    document.getElementById("modalImage");

const modalCategory =
    document.getElementById("modalCategory");

const modalTitle =
    document.getElementById("modalTitle");

const modalDescription =
    document.getElementById("modalDescription");

const modalTech =
    document.getElementById("modalTech");

const modalFeatures =
    document.getElementById("modalFeatures");

const liveDemo =
    document.getElementById("liveDemo");

const githubLink =
    document.getElementById("githubLink");



/* =========================================================
   OPEN PROJECT MODAL
========================================================= */

projectCards.forEach(card => {

    card.addEventListener("click", () => {

        const index =
            Number(card.dataset.project);

        const project =
            projectData[index];


        if (!project) {
            console.error(
                "Project not found:",
                index
            );

            return;
        }


        /* IMAGE */

        modalImage.src =
            project.image;

        modalImage.alt =
            project.title;


        /* CATEGORY */

        modalCategory.textContent =
            project.category;


        /* TITLE */

        modalTitle.textContent =
            project.title;


        /* DESCRIPTION */

        modalDescription.textContent =
            project.description;


        /* =================================================
           TECHNOLOGIES
        ================================================= */

        modalTech.innerHTML = "";


        project.technologies.forEach(
            technology => {

                const span =
                    document.createElement("span");

                span.textContent =
                    technology;

                modalTech.appendChild(span);

            }
        );


        /* =================================================
           FEATURES
        ================================================= */

        modalFeatures.innerHTML = "";


        project.features.forEach(
            feature => {

                const li =
                    document.createElement("li");

                li.textContent =
                    feature;

                modalFeatures.appendChild(li);

            }
        );


        /* =================================================
           LINKS
        ================================================= */

        liveDemo.href =
            project.live;

        githubLink.href =
            project.github;


        /* =================================================
           OPEN MODAL
        ================================================= */

        projectModal.classList.add("active");


        /* Prevent background scrolling */

        document.body.style.overflow =
            "hidden";

    });

});



/* =========================================================
   CLOSE MODAL FUNCTION
========================================================= */

function closeProjectModal() {

    projectModal.classList.remove("active");

    document.body.style.overflow = "";

}



/* =========================================================
   CLOSE BUTTON
========================================================= */

if (modalClose) {

    modalClose.addEventListener(
        "click",
        closeProjectModal
    );

}





/* =========================================================
   CLICK OUTSIDE MODAL
========================================================= */

if (projectModal) {

    projectModal.addEventListener(
        "click",
        event => {

            if (
                event.target ===
                projectModal
            ) {

                closeProjectModal();

            }

        }
    );

}



/* =========================================================
   ESC KEY
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape" &&
            projectModal.classList.contains("active")
        ) {

            closeProjectModal();

        }

    }
);


/* =========================================================
   RESUME SCROLL REVEAL
========================================================= */

const resumeElements = document.querySelectorAll(".reveal-resume");

const resumeObserver = new IntersectionObserver(
    (entries, observer) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("show");

                observer.unobserve(entry.target);

            }

        });

    },
    {
        threshold: 0.15
    }
);


resumeElements.forEach((element) => {
    resumeObserver.observe(element);
});

/* =========================================================
   WHAT I DO - SCROLL ANIMATION
========================================================= */

const serviceElements =
    document.querySelectorAll(".reveal-service");

const serviceObserver = new IntersectionObserver(
    (entries, observer) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("show");

                observer.unobserve(entry.target);
            }

        });

    },
    {
        threshold: 0.12
    }
);


serviceElements.forEach((element) => {
    serviceObserver.observe(element);
});

/* =========================================================
   REVIEWS SLIDER
========================================================= */

const reviewData = [

    {
        image:"images/reviews/shreya.jpeg",
        name: "Shreya Maity",
        role: "Web Developer",
        text: "She is a dedicated learner with a strong interest in web development. She consistently works on improving her technical skills and practical knowledge."
    },

    {
          image:"images/reviews/anita.jpeg",
        name: "Anita Jana",
        role: "Project Collaborator",
        text: "Working with her on projects has been a great experience. She is responsible, cooperative and always willing to learn and solve problems."
    },

    {
        image:"images/reviews/rinki.jpeg",
        name: "Rinki Das",
        role: "BCA Student | Classmate",
        text: "I'm really impressed by her creativity, dedication and ability to turn ideas into beautiful and functional websites. She is a great team player and always open to learning new things."
    },

    {
        image:"images/reviews/anita.jpeg",
        name: "Anita Jana",
        role: "BCA Graduate",
        text: "She is hardworking and passionate about web development. She is always eager to learn new technologies and improve her skills."
    },

    {
        image:"images/reviews/iti.png",
        name: "Itishree Ghorai",
        role: "Client",
        text: "Very creative and professional. She understands requirements well and delivers quality work on time. Highly recommended."
    },

    {
        image:"images/reviews/priya.png",
        name: "Priyanka Mondal",
        role: "Project Collaborator",
        text: "She is curious, consistent and always interested in learning. Her dedication to improving her development skills is clearly visible in her projects."
    }

];


const reviewTrack =
    document.getElementById("reviewTrack");

const reviewDots =
    document.getElementById("reviewDots");

const reviewNumber =
    document.getElementById("reviewNumber");

const reviewPrev =
    document.getElementById("reviewPrev");

const reviewNext =
    document.getElementById("reviewNext");


let activeReview = 0;

let reviewInterval;


/* =========================================================
   CREATE REVIEW CARDS
========================================================= */

function createReviews() {

    reviewTrack.innerHTML = "";

    reviewData.forEach((review, index) => {

        const card =
            document.createElement("article");

        card.className = "review-card";

        card.innerHTML = `

            <div class="review-card-top">

               <div class="review-avatar">
    <img src="${review.image}" alt="${review.name}">
</div>

                <div class="review-stars">

                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>

                </div>

            </div>


            <div class="review-quote">
                “
            </div>


            <p class="review-text">
                "${review.text}"
            </p>


            <div class="review-person">

                <h4 class="review-name">
                    ${review.name}
                </h4>

                <span class="review-role">
                    ${review.role}
                </span>

            </div>

        `;

        reviewTrack.appendChild(card);

    });

}


/* =========================================================
   CREATE DOTS
========================================================= */

function createReviewDots() {

    reviewDots.innerHTML = "";

    reviewData.forEach((_, index) => {

        const dot =
            document.createElement("button");

        dot.className = "review-dot";

        dot.setAttribute(
            "aria-label",
            `Show review ${index + 1}`
        );

        dot.addEventListener(
            "click",
            () => {

                activeReview = index;

                updateReviews();

                restartReviewSlider();

            }
        );

        reviewDots.appendChild(dot);

    });

}


/* =========================================================
   UPDATE REVIEW POSITIONS
========================================================= */

function updateReviews() {

    const cards =
        document.querySelectorAll(".review-card");

    const dots =
        document.querySelectorAll(".review-dot");


    const total =
        reviewData.length;


    cards.forEach((card, index) => {

        let difference =
            index - activeReview;


        /*
         * Circular positioning
         */

        if (difference > total / 2) {

            difference -= total;

        }

        if (difference < -total / 2) {

            difference += total;

        }


        /*
         * Desktop positions
         */

        let positionX = 0;

        let scale = 0.72;

        let opacity = 0;

        let zIndex = 1;

        let pointer = "none";


        if (difference === 0) {

            positionX = 0;

            scale = 1;

            opacity = 1;

            zIndex = 10;

            pointer = "auto";

            card.classList.add("active");

        }

        else if (difference === -1) {

            positionX = -370;

            scale = 0.82;

            opacity = .88;

            zIndex = 7;

            pointer = "auto";

            card.classList.remove("active");

        }

        else if (difference === 1) {

            positionX = 370;

            scale = 0.82;

            opacity = .88;

            zIndex = 7;

            pointer = "auto";

            card.classList.remove("active");

        }

        else if (difference === -2) {

            positionX = -675;

            scale = 0.70;

            opacity = .52;

            zIndex = 4;

            pointer = "none";

            card.classList.remove("active");

        }

        else if (difference === 2) {

            positionX = 675;

            scale = 0.70;

            opacity = .52;

            zIndex = 4;

            pointer = "none";

            card.classList.remove("active");

        }

        else {

            positionX =
                difference > 0
                    ? 1000
                    : -1000;

            scale = 0.6;

            opacity = 0;

            zIndex = 1;

            pointer = "none";

            card.classList.remove("active");

        }


        /*
         * Mobile
         */

        if (window.innerWidth <= 768) {

            if (difference === 0) {

                positionX = 0;

                scale = 1;

                opacity = 1;

                zIndex = 10;

            }

            else if (difference === -1) {

                positionX = -430;

                scale = .75;

                opacity = .25;

                zIndex = 3;

            }

            else if (difference === 1) {

                positionX = 430;

                scale = .75;

                opacity = .25;

                zIndex = 3;

            }

            else {

                positionX =
                    difference > 0
                        ? 700
                        : -700;

                scale = .65;

                opacity = 0;

                zIndex = 1;

            }

        }


        card.style.setProperty(
            "--position-x",
            `${positionX}px`
        );

        card.style.setProperty(
            "--scale",
            scale
        );

        card.style.setProperty(
            "--opacity",
            opacity
        );

        card.style.setProperty(
            "--z-index",
            zIndex
        );

        card.style.setProperty(
            "--pointer",
            pointer
        );

    });


    /*
     * Update dots
     */

    dots.forEach((dot, index) => {

        dot.classList.toggle(
            "active",
            index === activeReview
        );

    });


    /*
     * Counter
     */

    reviewNumber.textContent =
        String(activeReview + 1).padStart(2, "0");

}


/* =========================================================
   NEXT REVIEW
========================================================= */

function nextReview() {

    activeReview++;

    if (activeReview >= reviewData.length) {

        activeReview = 0;

    }

    updateReviews();

}


/* =========================================================
   PREVIOUS REVIEW
========================================================= */

function previousReview() {

    activeReview--;

    if (activeReview < 0) {

        activeReview =
            reviewData.length - 1;

    }

    updateReviews();

}


/* =========================================================
   BUTTONS
========================================================= */

reviewNext.addEventListener(
    "click",
    () => {

        nextReview();

        restartReviewSlider();

    }
);


reviewPrev.addEventListener(
    "click",
    () => {

        previousReview();

        restartReviewSlider();

    }
);


/* =========================================================
   AUTO SLIDER
========================================================= */

function startReviewSlider() {

    reviewInterval =
        setInterval(() => {

            nextReview();

        }, 4500);

}


function restartReviewSlider() {

    clearInterval(reviewInterval);

    startReviewSlider();

}


/* =========================================================
   PAUSE ON HOVER
========================================================= */

reviewTrack.addEventListener(
    "mouseenter",
    () => {

        clearInterval(reviewInterval);

    }
);


reviewTrack.addEventListener(
    "mouseleave",
    () => {

        startReviewSlider();

    }
);


/* =========================================================
   RESIZE
========================================================= */

window.addEventListener(
    "resize",
    () => {

        updateReviews();

    }
);


/* =========================================================
   INITIALIZE
========================================================= */

createReviews();

createReviewDots();

updateReviews();

startReviewSlider();


/* =========================================================
   CONTACT SECTION ANIMATION
========================================================= */

const contactElements =
    document.querySelectorAll(".reveal-contact");


const contactObserver =
    new IntersectionObserver(
        (entries, observer) => {

            entries.forEach(entry => {

                if (entry.isIntersecting) {

                    entry.target.classList.add("show");

                    observer.unobserve(entry.target);

                }

            });

        },
        {
            threshold: 0.15
        }
    );


contactElements.forEach(element => {

    contactObserver.observe(element);

});


/* =========================================================
   CONTACT FORM
========================================================= */

const contactForm = document.getElementById("contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", async function (e) {

        e.preventDefault();

        const submitButton = contactForm.querySelector(".contact-submit");

        const originalText = submitButton.innerHTML;

        submitButton.disabled = true;
        submitButton.innerHTML = "Sending...";

        const formData = new FormData(contactForm);

        try {

            const response = await fetch("php/contact.php", {
                method: "POST",
                body: formData
            });

            const result = await response.json();

            if (result.success) {

                submitButton.innerHTML = "Message Sent";

                contactForm.reset();

                setTimeout(() => {

                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;

                }, 2500);

            } else {

                alert(result.message);

                submitButton.innerHTML = originalText;
                submitButton.disabled = false;

            }

        } catch (error) {

            console.error("Error:", error);

            alert("Something went wrong. Please try again.");

            submitButton.innerHTML = originalText;
            submitButton.disabled = false;
        }

    });

}

/* =====================================================
   FOOTER
===================================================== */

// Current Year

const currentYear = document.getElementById("currentYear");

if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
}


/* =====================================================
   BACK TO TOP
===================================================== */

const backToTop = document.getElementById("backToTop");

if (backToTop) {

    backToTop.addEventListener("click", () => {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    });

}


/* =====================================================
   FOOTER REVEAL ANIMATION
===================================================== */

const footerElements =
    document.querySelectorAll(".footer-reveal");

const footerObserver = new IntersectionObserver(
    (entries) => {

        entries.forEach((entry) => {

            if (entry.isIntersecting) {

                entry.target.classList.add("show");

            }

        });

    },
    {
        threshold: 0.15
    }
);


footerElements.forEach((element) => {

    footerObserver.observe(element);

});


/* =========================================
   BASIC ANTI-INSPECT PROTECTION
========================================= */

// Disable Right Click
document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
});

// Disable common keyboard shortcuts
document.addEventListener("keydown", function (e) {

    // F12
    if (e.key === "F12") {
        e.preventDefault();
    }

    // Ctrl + Shift + I
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "i") {
        e.preventDefault();
    }

    // Ctrl + Shift + J
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "j") {
        e.preventDefault();
    }

    // Ctrl + Shift + C
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "c") {
        e.preventDefault();
    }

    // Ctrl + U
    if (e.ctrlKey && e.key.toLowerCase() === "u") {
        e.preventDefault();
    }

});
