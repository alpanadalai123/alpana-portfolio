<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title></title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.css" integrity="sha512-x9WwyMYBnlXMNQ6kQ/Lyzu1NqIhLQKL5Oq6xByfXuRj7s9CskyCbLv/1IjqzJmXwFXWr0ov6jBV7Qbc0hh9nHg==" crossorigin="anonymous" referrerpolicy="no-referrer">

    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!-- ================= LOADER ================= -->

    <div class="loader">

        <div class="loader-book">

            <div class="book-cover">
                <span>A</span>
            </div>

            <div class="book-pages">

                <div class="page page-1"></div>
                <div class="page page-2"></div>
                <div class="page page-3"></div>

            </div>

            <div class="book-cover right-cover">
                <span>D</span>
            </div>

        </div>

        <p>ALPANA DALAI</p>

        <small>PORTFOLIO</small>

    </div>


    <!-- ================= NAVBAR ================= -->

    <header class="navbar">

        <a href="#" class="logo">
            A<span>.</span>
        </a>

        <nav class="nav-menu" id="navMenu">

            <a href="#home" class="active">Home</a>
            <a href="#about">About</a>
            <a href="#skills">Skills</a>
            <a href="#projects">Projects</a>
            <a href="#resume">Resume</a>
            <a href="#services">What I Do</a>
            <a href="#contact">Contact</a>

        </nav>

        <a href="#contact" class="talk-btn">
            Let's Talk <span>↗</span>
        </a>

        <button class="hamburger" id="hamburger">

            <i></i>
            <i></i>
            <i></i>

        </button>

    </header>


    <!-- ================= HERO ================= -->

    <main>

        <section class="hero" id="home">

            <!-- background decoration -->

            <div class="gradient-ball ball-1"></div>
            <div class="gradient-ball ball-2"></div>

            <div class="shape plus">+</div>
            <div class="shape star">✳</div>
            <div class="shape circle">○</div>
            <div class="shape slash">/</div>

            <div class="dots dots-1"></div>
            <div class="dots dots-2"></div>
            <div class="dots dots-3"></div>


            <!-- ================= IMAGE ================= -->

            <div class="hero-photo">

                <div class="photo-bg"></div>

                <div class="photo-border"></div>

                <div class="photo-box">

                    <img src="images/alp.png"
                        alt="Alpana Dalai">

                </div>


                <div class="photo-tag">

                    <span></span>

                    CREATIVE DEVELOPER

                </div>


                <!-- <div class="number-tag">

                    <strong>01</strong>

                    <div>
                        WEB<br>
                        DEVELOPER
                    </div>

                </div> -->

            </div>


            <!-- ================= CONTENT ================= -->

            <div class="hero-content">

                <div class="intro">

                    <span></span>

                    HELLO, I'M ALPANA

                </div>


                <h1>

                    Creating
                    <br>

                    <em>digital</em>
                    experiences.

                </h1>


                <div class="designation">

                    <span></span>

                    WEB DEVELOPER

                    <b>•</b>

                    BCA STUDENT

                </div>


                <p>

                    I build modern, responsive and interactive
                    websites where clean code meets creative
                    design.

                </p>


                <div class="buttons">

                    <a href="#projects" class="primary-btn">

                        View My Work

                        <span>↗</span>

                    </a>


                    <a href="#contact" class="secondary-btn">

                        Let's Connect

                        <span>→</span>

                    </a>

                </div>


                <div class="bottom-info">

                    <div>

                        <small>BASED IN</small>

                        <strong>INDIA</strong>

                    </div>

                    <div>

                        <small>PASSION</small>

                        <strong>CODE & DESIGN</strong>

                    </div>

                </div>

            </div>


            <!-- scroll -->

            <div class="scroll">

                <span>SCROLL TO EXPLORE</span>

                <div class="scroll-arrow">
                    ↓
                </div>

            </div>

        </section>

        <section class="about-section" id="about">

    <div class="about-bg-circle circle-1"></div>
    <div class="about-bg-circle circle-2"></div>

    <div class="about-container">

        <!-- LEFT : IMAGE -->
        <div class="about-image-wrap reveal-about">

            <div class="about-image-shape"></div>

            <div class="about-image">
                <img src="images/alp.png" alt="Alpana Dalai">
            </div>

            <div class="about-floating-card">
                <span class="code-icon">&lt;/&gt;</span>
                <div>
                    <strong>Creative Developer</strong>
                    <small>Building & Learning</small>
                </div>
            </div>

        </div>


        <!-- RIGHT : CONTENT -->
        <div class="about-content reveal-about">

            <div class="about-label">
                <span></span>
                ABOUT ME
            </div>

            <h2>
                Turning ideas into
                <em>digital reality.</em>
            </h2>

            <p class="about-intro">
                I'm <strong>Alpana Dalai</strong>, a BCA student and
                aspiring web developer who enjoys creating clean,
                responsive and engaging digital experiences.
            </p>

            <p class="about-description">
                I love combining technology and creativity to build
                websites that are visually attractive, easy to use
                and responsive across different devices.
            </p>

            <p class="about-description">
                My development journey includes working with
                <strong>HTML, CSS, JavaScript, Java, C, C++</strong>
                and <strong>.NET</strong>. I'm continuously learning,
                experimenting and improving my development skills.
            </p>


            <!-- STATS -->
            <div class="about-stats">

                <div class="stat-box">
                    <h3>
                        <span class="counter" data-target="10">0</span>+
                    </h3>
                    <p>Projects</p>
                </div>

                <div class="stat-box">
                    <h3>
                        <span class="counter" data-target="6">0</span>+
                    </h3>
                    <p>Technologies</p>
                </div>

                <div class="stat-box">
                    <h3>
                        <span class="counter" data-target="100">0</span>%
                    </h3>
                    <p>Learning</p>
                </div>

            </div>


            <div class="about-bottom">

                <div class="available">
                    <span></span>
                    Currently learning & building
                </div>

                <a href="#portfolio">
                    Explore my work
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>

            </div>

        </div>

    </div>

</section>

<!-- =========================
     SKILLS SECTION
========================= -->

<section class="skills-section" id="skills">

    <!-- Background -->
    <div class="skills-orb skills-orb-1"></div>
    <div class="skills-orb skills-orb-2"></div>

    <div class="skills-container">

        <!-- Heading -->
        <div class="skills-heading reveal-skill">

            <div class="skills-label">
                <span></span>
                MY SKILLS
            </div>

            <div class="skills-title-row">

                <span class="skills-number">02</span>

                <h2>
                    Tools I use to
                    <em>build ideas.</em>
                </h2>

            </div>

            <p>
                A growing collection of technologies and tools
                I use to create modern, responsive and functional
                digital experiences.
            </p>

        </div>


        <!-- Skills Cards -->
        <div class="skills-grid">


            <!-- WEB DEVELOPMENT -->
            <div class="skill-card reveal-skill">

                <div class="skill-card-top">

                    <div class="skill-icon">
                        <i class="fa-solid fa-code"></i>
                    </div>

                    <span>01</span>

                </div>

                <h3>Web Development</h3>

                <p class="skill-card-desc">
                    Creating clean, responsive and interactive
                    websites with modern web technologies.
                </p>


                <!-- HTML -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>HTML</span>
                        <b>95%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="95%"></span>
                    </div>

                </div>


                <!-- CSS -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>CSS</span>
                        <b>90%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="90%"></span>
                    </div>

                </div>


                <!-- JavaScript -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>JavaScript</span>
                        <b>85%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="85%"></span>
                    </div>

                </div>


                <!-- React -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>React</span>
                        <b>75%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="75%"></span>
                    </div>

                </div>

            </div>



            <!-- PROGRAMMING -->
            <div class="skill-card reveal-skill">

                <div class="skill-card-top">

                    <div class="skill-icon">
                        <i class="fa-solid fa-terminal"></i>
                    </div>

                    <span>02</span>

                </div>

                <h3>Programming</h3>

                <p class="skill-card-desc">
                    Building programming fundamentals and
                    improving problem-solving through code.
                </p>


                <!-- Java -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>Java</span>
                        <b>80%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="80%"></span>
                    </div>

                </div>


                <!-- C -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>C</span>
                        <b>80%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="80%"></span>
                    </div>

                </div>


                <!-- C++ -->
                <div class="skill-item">

                    <div class="skill-info">
                        <span>C++</span>
                        <b>75%</b>
                    </div>

                    <div class="skill-bar">
                        <span data-width="75%"></span>
                    </div>

                </div>

            </div>



            <!-- BACKEND -->
            <div class="skill-card skill-card-wide reveal-skill">

                <div class="skill-card-top">

                    <div class="skill-icon">
                        <i class="fa-solid fa-database"></i>
                    </div>

                    <span>03</span>

                </div>

                <h3>Backend & Database</h3>

                <p class="skill-card-desc">
                    Working with server-side technologies,
                    APIs and databases to build complete applications.
                </p>


                <div class="technology-list">

                    <div class="technology">
                        <i class="fa-brands fa-php"></i>
                        <span>PHP</span>
                    </div>

                    <div class="technology">
                        <i class="fa-brands fa-node-js"></i>
                        <span>Node.js</span>
                    </div>

                    <div class="technology">
                        <i class="fa-solid fa-database"></i>
                        <span>MySQL</span>
                    </div>

                    <div class="technology">
                        <i class="fa-brands fa-laravel"></i>
                        <span>Laravel</span>
                    </div>

                </div>

            </div>



            <!-- TOOLS -->
            <div class="skill-card skill-card-tools reveal-skill">

                <div class="skill-card-top">

                    <div class="skill-icon">
                        <i class="fa-solid fa-wrench"></i>
                    </div>

                    <span>04</span>

                </div>

                <h3>Tools</h3>

                <div class="tools-list">

                    <span>Git</span>
                    <span>GitHub</span>
                    <span>VS Code</span>
                    <span>Postman</span>

                </div>

            </div>

        </div>



        <!-- FLOATING SKILLS -->
        <div class="floating-skills">

            <span>HTML</span>
            <span>CSS</span>
            <span>JAVA</span>
            <span>REACT</span>
            <span>NODE</span>
            <span>PHP</span>

        </div>

    </div>

</section>

<!-- =====================================================
     PROJECTS SECTION
===================================================== -->

<section class="projects-section" id="projects">

    <div class="projects-container">

        <!-- SECTION HEADING -->

        <div class="projects-heading">

            <div class="projects-label">
                <span></span>
                MY PROJECTS
            </div>

            <div class="projects-title-row">

                <span class="projects-number">
                    03
                </span>

                <h2>
                    Things I've
                    <em>built.</em>
                </h2>

            </div>

            <p>
                A collection of projects where I combine
                creativity, technology and problem-solving
                to build useful digital experiences.
            </p>

        </div>


        <!-- =================================================
             PROJECT GRID
        ================================================= -->

        <div class="projects-grid">


            <!-- PROJECT 1 -->

            <article
                class="project-card"
                data-project="0">

                <div class="project-image">

                    <img
                        src="images/projects/burger.png"
                        alt="Burger E-Commerce">

                    <div class="project-overlay">

                        <span>
                            View Project

                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        </span>

                    </div>

                </div>


                <div class="project-card-content">

                    <span class="project-category">
                        WEB DEVELOPMENT
                    </span>

                    <h3>
                        Burger E-Commerce
                    </h3>

                    <p>
                        A modern food e-commerce website
                        with products, cart and customer
                        interaction.
                    </p>

                    <div class="project-tech">

                        <span>HTML</span>
                        <span>CSS</span>
                        <span>PHP</span>
                        <span>MySQL</span>

                    </div>

                </div>

            </article>



            <!-- PROJECT 2 -->

            <article
                class="project-card"
                data-project="1">

                <div class="project-image">

                    <img
                        src="images/projects/computer.png"
                        alt="Computer Repair Website">

                    <div class="project-overlay">

                        <span>
                            View Project

                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        </span>

                    </div>

                </div>


                <div class="project-card-content">

                    <span class="project-category">
                        WEB DESIGN
                    </span>

                    <h3>
                        Computer Repair
                    </h3>

                    <p>
                        A professional computer repair
                        and support website with services
                        and repair booking.
                    </p>

                    <div class="project-tech">

                        <span>HTML</span>
                        <span>CSS</span>
                        <span>JavaScript</span>

                    </div>

                </div>

            </article>



            <!-- PROJECT 3 -->

            <article
                class="project-card"
                data-project="2">

                <div class="project-image">

                    <img
                        src="images/projects/pokemon.png"
                        alt="Pokemon Explorer">

                    <div class="project-overlay">

                        <span>
                            View Project

                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        </span>

                    </div>

                </div>


                <div class="project-card-content">

                    <span class="project-category">
                        REACT PROJECT
                    </span>

                    <h3>
                        Pokémon Explorer
                    </h3>

                    <p>
                        React application using the
                        Pokémon API to display dynamic
                        Pokémon information.
                    </p>

                    <div class="project-tech">

                        <span>React</span>
                        <span>Axios</span>
                        <span>API</span>

                    </div>

                </div>

            </article>



            <!-- PROJECT 4 -->

            <article
                class="project-card"
                data-project="3">

                <div class="project-image">

                    <img
                        src="images/projects/dashboard.png"
                        alt="Education Dashboard">

                    <div class="project-overlay">

                        <span>
                            View Project

                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        </span>

                    </div>

                </div>


                <div class="project-card-content">

                    <span class="project-category">
                        REACT UI
                    </span>

                    <h3>
                        Education Dashboard
                    </h3>

                    <p>
                        A modern responsive education
                        dashboard built with reusable
                        React components.
                    </p>

                    <div class="project-tech">

                        <span>React</span>
                        <span>Tailwind</span>
                        <span>JavaScript</span>

                    </div>

                </div>

            </article>



            <!-- PROJECT 5 -->

            <article
                class="project-card"
                data-project="4">

                <div class="project-image">

                    <img
                        src="images/projects/sc.png"
                        alt="School Website">

                    <div class="project-overlay">

                        <span>
                            View Project

                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        </span>

                    </div>

                </div>


                <div class="project-card-content">

                    <span class="project-category">
                        WEB DESIGN
                    </span>

                    <h3>
                        School Website
                    </h3>

                    <p>
                        Responsive school website with
                        academic information, events,
                        gallery and facilities.
                    </p>

                    <div class="project-tech">

                        <span>HTML</span>
                        <span>CSS</span>
                        <span>JavaScript</span>
                        <span>Bootstrap</span>

                    </div>

                </div>

            </article>



            <!-- PROJECT 6 -->

            <article
                class="project-card"
                data-project="5">

                <div class="project-image">

                    <img
                        src="images/projects/portfolio.png"
                        alt="Personal Portfolio">

                    <div class="project-overlay">

                        <span>
                            View Project

                            <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        </span>

                    </div>

                </div>


                <div class="project-card-content">

                    <span class="project-category">
                        PORTFOLIO
                    </span>

                    <h3>
                        Personal Portfolio
                    </h3>

                    <p>
                        A modern animated portfolio
                        website showcasing skills,
                        projects and development work.
                    </p>

                    <div class="project-tech">

                        <span>HTML</span>
                        <span>CSS</span>
                        <span>JavaScript</span>

                    </div>

                </div>

            </article>


        </div>

    </div>

</section>



<!-- =====================================================
     PROJECT MODAL
===================================================== -->

<div
    class="project-modal"
    id="projectModal">


    <div class="modal-box">


        <!-- CLOSE -->

        <button
            class="modal-close"
            id="modalClose"
            aria-label="Close project">

            <i class="fa-solid fa-xmark"></i>

        </button>



        <!-- LEFT IMAGE -->

        <div class="modal-image">

            <div class="modal-image-inner">

                <img
                    id="modalImage"
                    src=""
                    alt="Project Preview">

            </div>

        </div>



        <!-- RIGHT CONTENT -->

        <div class="modal-content">


            <span
                class="modal-category"
                id="modalCategory">
                WEB DESIGN
            </span>


            <h2 id="modalTitle">
                Project Title
            </h2>


            <div class="modal-line"></div>


            <p id="modalDescription">
                Project description.
            </p>



            <!-- TECHNOLOGIES -->

            <div class="modal-section">

                <h4>
                    Technologies
                </h4>

                <div
                    class="modal-tech"
                    id="modalTech">
                </div>

            </div>



            <!-- FEATURES -->

            <div class="modal-section">

                <h4>
                    Key Features
                </h4>

                <ul
                    id="modalFeatures">
                </ul>

            </div>



            <!-- BUTTONS -->

            <div class="modal-buttons">


                <!-- LIVE DEMO -->

                <a
                    href="#"
                    target="_blank"
                    rel="noopener noreferrer"
                    id="liveDemo"
                    class="live-demo">

                    <i class="fa-solid fa-arrow-up-right-from-square"></i>

                    Live Demo

                </a>



                <!-- VIEW CODE -->

                <a
                    href="#"
                    target="_blank"
                    rel="noopener noreferrer"
                    id="githubLink"
                    class="github-button">

                    <i class="fa-brands fa-github"></i>

                    View Code

                </a>


            </div>


        </div>

    </div>

</div>

<!-- ================= RESUME / JOURNEY SECTION ================= -->

<section class="resume-section" id="resume">

    <!-- Background Decorations -->
    <div class="resume-orb resume-orb-1"></div>
    <div class="resume-orb resume-orb-2"></div>

    <div class="resume-container">

        <!-- Section Heading -->
        <div class="resume-heading reveal-resume">

            <div class="resume-label">
                <span></span>
                MY JOURNEY
            </div>

            <h2>
                Experience & <em>Education.</em>
            </h2>

            <p>
                A quick look at my learning journey, practical experience
                and the path I'm following to become a better developer.
            </p>

        </div>


        <!-- Timeline Grid -->
        <div class="resume-grid">


            <!-- ================= EXPERIENCE ================= -->

            <div class="resume-column">

                <div class="resume-column-title reveal-resume">

                    <div class="resume-title-icon">
                        <i class="fa-solid fa-briefcase"></i>
                    </div>

                    <div>
                        <span>01</span>
                        <h3>Experience</h3>
                    </div>

                </div>


                <div class="timeline">


                    <!-- Experience 1 -->
                    <div class="timeline-item reveal-resume">

                        <div class="timeline-dot active"></div>

                        <div class="timeline-card">

                            <div class="timeline-top">
                                <span class="timeline-year">
                                    2026 — Present
                                </span>

                                <span class="timeline-status">
                                    Current
                                </span>
                            </div>

                            <h4>Frontend Development Trainee</h4>

                            <h5>
                                Web Development
                            </h5>

                            <p>
                                Learning and applying modern frontend
                                technologies while working on practical
                                projects and improving problem-solving
                                and development skills.
                            </p>

                            <div class="timeline-tags">
                                <span>HTML</span>
                                <span>CSS</span>
                                <span>JavaScript</span>
                                <span>React</span>
                            </div>

                        </div>

                    </div>


                    <!-- Experience 2 -->
                    <div class="timeline-item reveal-resume">

                        <div class="timeline-dot"></div>

                        <div class="timeline-card">

                            <div class="timeline-top">

                                <span class="timeline-year">
                                    2025 — Present
                                </span>

                                <span class="timeline-type">
                                    Freelance
                                </span>

                            </div>

                            <h4>Frontend Web Developer</h4>

                            <h5>
                                Freelance / Personal Projects
                            </h5>

                            <p>
                                Developing responsive and user-friendly
                                websites using modern web technologies.
                                Focused on clean design, functionality
                                and smooth user experience.
                            </p>

                            <div class="timeline-tags">
                                <span>HTML</span>
                                <span>CSS</span>
                                <span>JavaScript</span>
                                <span>PHP</span>
                            </div>

                        </div>

                    </div>


                    <!-- Experience 3 -->
                    <div class="timeline-item reveal-resume">

                        <div class="timeline-dot"></div>

                        <div class="timeline-card">

                            <div class="timeline-top">

                                <span class="timeline-year">
                                    2024 — Present
                                </span>

                                <span class="timeline-type">
                                    Personal
                                </span>

                            </div>

                            <h4>Web Developer</h4>

                            <h5>
                                Personal Web Development
                            </h5>

                            <p>
                                Building practical web projects to
                                strengthen frontend development,
                                API integration, responsive design
                                and modern web development skills.
                            </p>

                            <div class="timeline-tags">
                                <span>React</span>
                                <span>Node.js</span>
                                <span>PHP</span>
                                <span>MySQL</span>
                            </div>

                        </div>

                    </div>

                </div>

            </div>



            <!-- ================= EDUCATION ================= -->

            <div class="resume-column">

                <div class="resume-column-title reveal-resume">

                    <div class="resume-title-icon education-icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>

                    <div>
                        <span>02</span>
                        <h3>Education</h3>
                    </div>

                </div>


                <div class="timeline">


                    <!-- Education 1 -->
                    <div class="timeline-item reveal-resume">

                        <div class="timeline-dot active"></div>

                        <div class="timeline-card">

                            <div class="timeline-top">

                                <span class="timeline-year">
                                    2024 — 2028
                                </span>

                                <span class="timeline-status">
                                    Ongoing
                                </span>

                            </div>

                            <h4>
                                Bachelor of Computer Application
                            </h4>

                            <h5>
                                Seacom Skills University
                            </h5>

                            <p>
                                Currently pursuing a BCA degree with
                                a focus on programming, web development,
                                databases and software development.
                            </p>

                            <div class="timeline-tags">
                                <span>Programming</span>
                                <span>Web Development</span>
                                <span>Database</span>
                            </div>

                        </div>

                    </div>


                    <!-- Education 2 -->
                    <div class="timeline-item reveal-resume">

                        <div class="timeline-dot"></div>

                        <div class="timeline-card">

                            <div class="timeline-top">

                                <span class="timeline-year">
                                    2022 — 2024
                                </span>

                            </div>

                            <h4>
                                Higher Secondary Education
                            </h4>

                            <h5>
                                Dhandalibar High School
                            </h5>

                            <p>
                                Completed higher secondary education
                                with a focus on Bio-science and computer-related
                                subjects.
                            </p>

                        </div>

                    </div>


                    <!-- Education 3 -->
                    <div class="timeline-item reveal-resume">

                        <div class="timeline-dot"></div>

                        <div class="timeline-card">

                            <div class="timeline-top">

                                <span class="timeline-year">
                                    2020 — 2022
                                </span>

                            </div>

                            <h4>
                                Secondary Education
                            </h4>

                            <h5>
                               Dhandalibar High School
                            </h5>

                            <p>
                                Completed secondary education with a
                                strong foundation in core academic
                                subjects and computer studies.
                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Bottom Resume Action -->

        <div class="resume-action reveal-resume">

            <div class="resume-action-text">

                <span>
                    <i class="fa-solid fa-file-lines"></i>
                </span>

                <div>
                    <strong>Want to know more about me?</strong>
                    <small>
                        Take a look at my complete resume.
                    </small>
                </div>

            </div>


           
            <a href="alpana-dalai-resume.pdf"
               class="resume-download"
               download>

                Download Resume

                <i class="fa-solid fa-arrow-down"></i>

            </a>

        </div>

    </div>

</section>

<!-- =========================================================
     WHAT I DO SECTION
========================================================= -->

<section class="services-section" id="services">


    <!-- Background Decoration -->
    <div class="service-orb service-orb-1"></div>
    <div class="service-orb service-orb-2"></div>

    <div class="services-container">

        <!-- Section Heading -->
        <div class="services-heading reveal-service">

            <div class="services-label">
                <span></span>
                WHAT I DO
            </div>

            <div class="services-title-row">

                <span class="services-number">06</span>

                <h2>
                    Turning ideas into
                    <em>digital experiences.</em>
                </h2>

            </div>

            <p>
                I build modern, responsive and interactive digital
                experiences by combining clean design with practical
                development.
            </p>

        </div>


        <!-- Services -->
        <div class="services-grid">


            <!-- Service 01 -->
            <article class="service-card reveal-service">

                <div class="service-top">

                    <span class="service-number">
                        01
                    </span>

                    <div class="service-icon">
                        <i class="fa-solid fa-code"></i>
                    </div>

                </div>

                <div class="service-content">

                    <h3>
                        Frontend
                        <br>
                        Development
                    </h3>

                    <p>
                        Creating clean, responsive and interactive
                        websites using modern frontend technologies.
                    </p>

                </div>

                <div class="service-tech">
                    HTML
                    <span>•</span>
                    CSS
                    <span>•</span>
                    JavaScript
                </div>

                <div class="service-arrow">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </div>

            </article>


            <!-- Service 02 -->
            <article class="service-card reveal-service">

                <div class="service-top">

                    <span class="service-number">
                        02
                    </span>

                    <div class="service-icon">
                        <i class="fa-solid fa-mobile-screen-button"></i>
                    </div>

                </div>

                <div class="service-content">

                    <h3>
                        Responsive
                        <br>
                        Web Design
                    </h3>

                    <p>
                        Designing websites that look smooth and work
                        properly across desktop, tablet and mobile.
                    </p>

                </div>

                <div class="service-tech">
                    Responsive
                    <span>•</span>
                    UI/UX
                    <span>•</span>
                    CSS
                </div>

                <div class="service-arrow">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </div>

            </article>


            <!-- Service 03 -->
            <article class="service-card reveal-service">

                <div class="service-top">

                    <span class="service-number">
                        03
                    </span>

                    <div class="service-icon">
                        <i class="fa-solid fa-server"></i>
                    </div>

                </div>

                <div class="service-content">

                    <h3>
                        Backend &
                        <br>
                        Database
                    </h3>

                    <p>
                        Building basic server-side functionality and
                        database-driven web applications.
                    </p>

                </div>

                <div class="service-tech">
                    PHP
                    <span>•</span>
                    MySQL
                    <span>•</span>
                    Node.js
                </div>

                <div class="service-arrow">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </div>

            </article>


            <!-- Service 04 -->
            <article class="service-card reveal-service">

                <div class="service-top">

                    <span class="service-number">
                        04
                    </span>

                    <div class="service-icon">
                        <i class="fa-solid fa-plug"></i>
                    </div>

                </div>

                <div class="service-content">

                    <h3>
                        API &
                        <br>
                        Integration
                    </h3>

                    <p>
                        Connecting applications with APIs to fetch,
                        display and manage dynamic data.
                    </p>

                </div>

                <div class="service-tech">
                    REST API
                    <span>•</span>
                    Axios
                    <span>•</span>
                    JSON
                </div>

                <div class="service-arrow">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </div>

            </article>


            <!-- Service 05 -->
            <article class="service-card reveal-service">

                <div class="service-top">

                    <span class="service-number">
                        05
                    </span>

                    <div class="service-icon">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    </div>

                </div>

                <div class="service-content">

                    <h3>
                        Interactive
                        <br>
                        UI Development
                    </h3>

                    <p>
                        Adding smooth animations, interactions and
                        engaging visual elements to websites.
                    </p>

                </div>

                <div class="service-tech">
                    JavaScript
                    <span>•</span>
                    Animation
                    <span>•</span>
                    React
                </div>

                <div class="service-arrow">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </div>

            </article>


            <!-- Service 06 -->
            <article class="service-card service-card-featured reveal-service">

                <div class="service-top">

                    <span class="service-number">
                        06
                    </span>

                    <div class="service-icon">
                        <i class="fa-solid fa-screwdriver-wrench"></i>
                    </div>

                </div>

                <div class="service-content">

                    <h3>
                        Website
                        <br>
                        Improvement
                    </h3>

                    <p>
                        Improving existing websites through better
                        layouts, responsiveness, performance and UI.
                    </p>

                </div>

                <div class="service-tech">
                    UI
                    <span>•</span>
                    Bug Fixing
                    <span>•</span>
                    Optimization
                </div>

                <div class="service-arrow">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </div>

            </article>

        </div>


        <!-- Bottom Statement -->

        <div class="services-bottom reveal-service">

            <div class="services-bottom-line"></div>

            <p>
                <span>Have an idea?</span>
                Let's turn it into something useful.
            </p>

            <a href="#contact">
                Let's talk
                <i class="fa-solid fa-arrow-right"></i>
            </a>

        </div>

    </div>

</section>

<!-- =========================================================
     REVIEWS SECTION
========================================================= -->

<section class="reviews-section" id="reviews">

    <!-- Background Decoration -->
    <div class="review-bg review-bg-left"></div>
    <div class="review-bg review-bg-right"></div>

    <div class="review-orbit review-orbit-left"></div>
    <div class="review-orbit review-orbit-right"></div>

    <div class="review-dot-shape review-dot-left"></div>
    <div class="review-dot-shape review-dot-right"></div>

    <div class="review-sparkle sparkle-top">
        <i class="fa-solid fa-star"></i>
    </div>

    <div class="review-sparkle sparkle-bottom">
        <i class="fa-solid fa-star"></i>
    </div>


    <div class="reviews-wrapper">

        <!-- =========================================
             HEADING
        ========================================== -->

        <div class="reviews-heading">

            <div class="reviews-label">
                <span></span>
                REVIEWS
                <span></span>
            </div>

            <h2>
                What People Say About
                <br>
                <em>My Work.</em>
            </h2>

            <p>
                Here are some kind words from people I've worked with,
                learned from, and collaborated with on different projects.
            </p>

        </div>


        <!-- =========================================
             REVIEW SLIDER
        ========================================== -->

        <div class="reviews-main">

            <!-- Previous -->
            <button
                class="review-arrow review-arrow-left"
                id="reviewPrev"
                aria-label="Previous review"
            >
                <i class="fa-solid fa-arrow-left"></i>
            </button>


            <!-- Cards -->
            <div class="review-slider">

                <div
                    class="review-track"
                    id="reviewTrack"
                ></div>

            </div>


            <!-- Next -->
            <button
                class="review-arrow review-arrow-right"
                id="reviewNext"
                aria-label="Next review"
            >
                <i class="fa-solid fa-arrow-right"></i>
            </button>

        </div>


        <!-- =========================================
             DOTS + COUNTER
        ========================================== -->

        <div class="reviews-navigation">

            <div
                class="review-dots"
                id="reviewDots"
            ></div>

            <div class="review-counter">

                <span id="reviewNumber">
                    01
                </span>

                <span class="counter-line"></span>

                <span>
                    06
                </span>

            </div>

        </div>


        <!-- =========================================
             BOTTOM TEXT
        ========================================== -->

        <div class="review-bottom-text">

            <span>Real People</span>

            <br>

            <span>Real Feedback</span>

            <div class="bottom-underline"></div>

        </div>

    </div>

</section>


<!-- =========================================================
     CONTACT SECTION
========================================================= -->

<section class="contact-section" id="contact">

    <!-- Background Decorations -->
    <div class="contact-orb contact-orb-one"></div>
    <div class="contact-orb contact-orb-two"></div>

    <div class="contact-ring contact-ring-one"></div>
    <div class="contact-ring contact-ring-two"></div>

    <div class="contact-dot contact-dot-one"></div>
    <div class="contact-dot contact-dot-two"></div>


    <div class="contact-container">

        <!-- =========================================
             SECTION HEADING
        ========================================== -->

        <div class="contact-heading reveal-contact">

            <div class="contact-label">
                <span></span>
                CONTACT
                <span></span>
            </div>

            <h2>
                Let's build something
                <em>great together.</em>
            </h2>

            <p>
                Have a project in mind, a question, or simply want to
                say hello? I'd love to hear from you.
            </p>

        </div>


        <!-- =========================================
             CONTACT CONTENT
        ========================================== -->

        <div class="contact-content">


            <!-- =====================================
                 LEFT SIDE
            ====================================== -->

            <div class="contact-info reveal-contact">

                <span class="contact-small-title">
                    GET IN TOUCH
                </span>

                <h3>
                    Let's talk about
                    <span>your idea.</span>
                </h3>

                <p class="contact-description">
                    Whether you have a new project, collaboration idea,
                    internship opportunity or just want to connect,
                    feel free to reach out.
                </p>


                <!-- Email -->

                <a
                    href="mailto:yourmail@gmail.com"
                    class="contact-info-card"
                >

                    <div class="contact-info-icon">
                        <i class="fa-regular fa-envelope"></i>
                    </div>

                    <div class="contact-info-text">

                        <span>Email</span>

                        <strong>
                            alpanadalai750135@gmail.com
                        </strong>

                    </div>

                    <i class="fa-solid fa-arrow-up-right-from-square contact-card-arrow"></i>

                </a>


                <!-- Phone -->

                <a
                    href="tel:+917586815589"
                    class="contact-info-card"
                >

                    <div class="contact-info-icon">
                        <i class="fa-solid fa-phone"></i>
                    </div>

                    <div class="contact-info-text">

                        <span>Phone</span>

                        <strong>
                            +91 75868 15589
                        </strong>

                    </div>

                    <i class="fa-solid fa-arrow-up-right-from-square contact-card-arrow"></i>

                </a>


                <!-- Location -->

                <div class="contact-info-card">

                    <div class="contact-info-icon">
                        <i class="fa-solid fa-location-dot"></i>
                    </div>

                    <div class="contact-info-text">

                        <span>Location</span>

                        <strong>
                            West Bengal, India
                        </strong>

                    </div>

                </div>


                <!-- Social -->

                <div class="contact-social">

                    <span>FOLLOW ME</span>

                    <div class="contact-social-links">

                        <a
                            href="https://www.linkedin.com/in/alpana-dalai-0588223a5/"
                            target="_blank"
                            aria-label="LinkedIn"
                        >
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>

                        <a
                            href="https://github.com/alpanadalai123/"
                            target="_blank"
                            aria-label="GitHub"
                        >
                            <i class="fa-brands fa-github"></i>
                        </a>

                        <a
                            href="https://www.instagram.com/a_l_p_a_n_a_123?stkn=MThnanJpdTcydnJ6NA=="
                            aria-label="Instagram"
                        >
                            <i class="fa-brands fa-instagram"></i>
                        </a>

                        <a
                            href="https://www.facebook.com/share/1JsmxBoZKp/"
                            aria-label="Facebook"
                        >
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>

                    </div>

                </div>

            </div>


            <!-- =====================================
                 RIGHT SIDE FORM
            ====================================== -->

            <div class="contact-form-wrapper reveal-contact">

                <div class="contact-form-top">

                    <div>
                        <span>START A CONVERSATION</span>

                        <h3>
                            Send me a message
                        </h3>
                    </div>

                    <div class="contact-form-icon">
                        <i class="fa-regular fa-paper-plane"></i>
                    </div>

                </div>


                <form id="contactForm">


                    <!-- Name -->

                    <div class="form-group">

                        <label for="contactName">
                            Your Name
                        </label>

                        <div class="input-wrapper">

                            <i class="fa-regular fa-user"></i>

                            <input
                                type="text"
                                id="contactName"
                                name="name"
                                placeholder="Enter your name"
                                required
                            >

                        </div>

                    </div>


                    <!-- Email -->

                    <div class="form-group">

                        <label for="contactEmail">
                            Email Address
                        </label>

                        <div class="input-wrapper">

                            <i class="fa-regular fa-envelope"></i>

                            <input
                                type="email"
                                id="contactEmail"
                                name="email"
                                placeholder="Enter your email"
                                required
                            >

                        </div>

                    </div>


                    <!-- Subject -->

                    <div class="form-group">

                        <label for="contactSubject">
                            Subject
                        </label>

                        <div class="input-wrapper">

                            <i class="fa-regular fa-pen-to-square"></i>

                            <input
                                type="text"
                                id="contactSubject"
                                name="subject"
                                placeholder="What is this about?"
                                required
                            >

                        </div>

                    </div>


                    <!-- Message -->

                    <div class="form-group">

                        <label for="contactMessage">
                            Message
                        </label>

                        <div class="input-wrapper textarea-wrapper">

                            <i class="fa-regular fa-message"></i>

                            <textarea
                                id="contactMessage"
                                name="message"
                                rows="5"
                                placeholder="Tell me about your project..."
                                required
                            ></textarea>

                        </div>

                    </div>


                    <!-- Submit -->

                    <button
                        type="submit"
                        class="contact-submit"
                    >

                        <span>
                            Send Message
                        </span>

                        <i class="fa-solid fa-arrow-right"></i>

                    </button>

                </form>

            </div>

        </div>


        <!-- Bottom line -->

        <div class="contact-bottom reveal-contact">

            <span></span>

            <p>
                Available for freelance projects & collaborations
            </p>

            <span></span>

        </div>

    </div>

</section>

<!-- ================= FOOTER ================= -->
<footer class="footer-section">

    <!-- Animated Top Line -->
    <div class="footer-top-line"></div>

    <div class="footer-container">

        <!-- Decorative Floating Shapes -->
        <span class="footer-shape shape-1"></span>
        <span class="footer-shape shape-2"></span>
        <span class="footer-shape shape-3"></span>

        <!-- Footer Brand -->
        <div class="footer-brand footer-reveal">
            <a href="#home" class="footer-logo">
                ALPANA<span>.</span>
            </a>

            <p>
                I’m a passionate Web Developer who loves creating
                modern, responsive and attractive web experiences.
            </p>

            <a href="#contact" class="footer-work-btn">
                Let's Work Together
                <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <!-- Quick Links -->
        <div class="footer-column footer-reveal">
            <h3>Quick Links</h3>

            <ul>
                <li>
                    <a href="#home">
                        <i class="fa-solid fa-angle-right"></i>
                        Home
                    </a>
                </li>

                <li>
                    <a href="#about">
                        <i class="fa-solid fa-angle-right"></i>
                        About
                    </a>
                </li>

                <li>
                    <a href="#skills">
                        <i class="fa-solid fa-angle-right"></i>
                        Skills
                    </a>
                </li>

                <li>
                    <a href="#portfolio">
                        <i class="fa-solid fa-angle-right"></i>
                        Portfolio
                    </a>
                </li>

                <li>
                    <a href="#contact">
                        <i class="fa-solid fa-angle-right"></i>
                        Contact
                    </a>
                </li>
            </ul>
        </div>

        <!-- Services -->
        <div class="footer-column footer-reveal">
            <h3>What I Do</h3>

            <ul>
                <li>
                    <i class="fa-solid fa-code"></i>
                    Web Development
                </li>

                <li>
                    <i class="fa-solid fa-laptop-code"></i>
                    Frontend Development
                </li>

                <li>
                    <i class="fa-solid fa-mobile-screen"></i>
                    Responsive Design
                </li>

                <li>
                    <i class="fa-solid fa-palette"></i>
                    UI Design
                </li>

                <li>
                    <i class="fa-solid fa-gears"></i>
                    JavaScript Development
                </li>
            </ul>
        </div>

        <!-- Contact -->
        <div class="footer-column footer-reveal">
            <h3>Contact Me</h3>

            <div class="footer-contact">

                <a href="mailto:yourmail@gmail.com">
                    <span class="contact-icon">
                        <i class="fa-solid fa-envelope"></i>
                    </span>
                    <span>
                        <small>Email</small>
                        alpanadalai750135@gmail.com
                    </span>
                </a>

                <a href="tel:+917586815589">
                    <span class="contact-icon">
                        <i class="fa-solid fa-phone"></i>
                    </span>
                    <span>
                        <small>Phone</small>
                        +91 75868 15589
                    </span>
                </a>

                <a href="https://alpanadalai.online" target="_blank">
                    <span class="contact-icon">
                        <i class="fa-solid fa-globe"></i>
                    </span>
                    <span>
                        <small>Website</small>
                        alpanadalai.online
                    </span>
                </a>

            </div>
        </div>

    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">

        <div class="footer-bottom-content">

            <p>
                © <span id="currentYear"></span>
                <strong>Alpana Dalai</strong>.
                All Rights Reserved.
            </p>

            <!-- Social Icons -->
            <div class="footer-social">

                <a href="https://www.linkedin.com/in/alpana-dalai-0588223a5/"
                   target="_blank"
                   aria-label="LinkedIn">
                    <i class="fa-brands fa-linkedin-in"></i>
                </a>

                <a href="https://github.com/alpanadalai123/" aria-label="GitHub">
                    <i class="fa-brands fa-github"></i>
                </a>

                <a href="https://www.instagram.com/a_l_p_a_n_a_123?stkn=MThnanJpdTcydnJ6NA==" aria-label="Instagram">
                    <i class="fa-brands fa-instagram"></i>
                </a>

                <a href="https://www.facebook.com/share/1JsmxBoZKp/" aria-label="Facebook">
                    <i class="fa-brands fa-facebook-f"></i>
                </a>

            </div>

            <!-- Back To Top -->
            <button class="back-to-top" id="backToTop">
                <i class="fa-solid fa-arrow-up"></i>
            </button>

        </div>

    </div>

</footer>


    </main>


    <script src="script.js"></script>

</body>

</html>