<?php

header("Content-Type: application/json");

require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}


/* Get form data */

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$subject = trim($_POST["subject"] ?? "");
$message = trim($_POST["message"] ?? "");


/* Validation */

if ($name === "" || $email === "" || $subject === "" || $message === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "All fields are required."
    ]);

    exit;
}


/* Validate email */

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid email address."
    ]);

    exit;
}


/* Length validation */

if (strlen($name) > 100) {

    echo json_encode([
        "success" => false,
        "message" => "Name is too long."
    ]);

    exit;
}

if (strlen($subject) > 200) {

    echo json_encode([
        "success" => false,
        "message" => "Subject is too long."
    ]);

    exit;
}


/* Insert data */

try {

    $sql = "INSERT INTO contact_messages
            (name, email, subject, message)
            VALUES
            (:name, :email, :subject, :message)";

    $stmt = $conn->prepare($sql);

    $stmt->execute([
        ":name" => $name,
        ":email" => $email,
        ":subject" => $subject,
        ":message" => $message
    ]);


    echo json_encode([
        "success" => true,
        "message" => "Your message has been sent successfully."
    ]);

} catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Something went wrong. Please try again."
    ]);

}

?>